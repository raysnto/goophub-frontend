export const environment = {
  production: true,
  //baseUrl: 'http://3.22.167.44:8080'
  baseUrl: 'http://localhost:8080'
};
